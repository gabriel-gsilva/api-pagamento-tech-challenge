"""
Module: http/__init__.py
"""
from mercadopago.http.http_client import HttpClient


__all__ = (
    'HttpClient',
)
