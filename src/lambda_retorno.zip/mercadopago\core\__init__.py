"""
Module: core/__init__.py
"""
from mercadopago.core.mp_base import MPBase


__all__ = (
    'MPBase',
)
